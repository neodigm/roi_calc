import * as i0 from '@angular/core';
import { Component, Injectable, NgModule } from '@angular/core';
import * as i1 from '@angular/common/http';
import { HttpClientModule, HttpHeaders } from '@angular/common/http';
import * as CryptoJS from 'crypto-js';
import * as i2 from '@angular/router';

class ApiComponent {
}
ApiComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.0.2", ngImport: i0, type: ApiComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
ApiComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.0.2", type: ApiComponent, selector: "pnp-api", ngImport: i0, template: `
    <p>
      api works!
    </p>
  `, isInline: true });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.0.2", ngImport: i0, type: ApiComponent, decorators: [{
            type: Component,
            args: [{ selector: 'pnp-api', template: `
    <p>
      api works!
    </p>
  ` }]
        }] });

class AESEncryptDecryptService {
    constructor() {
        // secretKey = "BKGsN85lqJB0Slf5hcAKBkIkAWCYG5KrKCtWkgUrLGD=";
        this.secretKey = 'BKGsN85lqJB0Slf5';
        this.encryptedBase64Key = 'bXVzdGJlMTZieXRlc2tleQ==';
        this.parsedBase64Key = CryptoJS.enc.Base64.parse(this.encryptedBase64Key);
        this.substitutionsBeforeDecryption = new Map([
            ['-', '+'],
            ['_', '/'],
            ['=', '~'],
        ]);
    }
    // encrypt(value : string) : string{
    //   return CryptoJS.AES.encrypt(value, this.secretKey.trim()).toString();
    // }
    // decrypt(textToDecrypt : string){
    //   return CryptoJS.AES.decrypt(textToDecrypt, this.secretKey.trim()).toString(CryptoJS.enc.Utf8);
    // }
    //  encryptedData = null;
    // encryptedCipherText = 'U2WvSc8oTur1KkrB6VGNDmA3XxJb9cC+T9RnqT4kD90='; // or encryptedData;
    // console.log( “DecryptedData = “ + decryptedData );
    // this is the decrypted data as a string
    decrypt(encryptedCipherText) {
        const toDecrypt = encryptedCipherText.replace(/[-_~]/g, (match) => { var _a; return (_a = this.substitutionsBeforeDecryption.get(match)) !== null && _a !== void 0 ? _a : match; });
        let decryptedData = CryptoJS.AES.decrypt(toDecrypt, this.parsedBase64Key, {
            mode: CryptoJS.mode.ECB,
            padding: CryptoJS.pad.Pkcs7
        });
        return decryptedData.toString(CryptoJS.enc.Utf8);
    }
    encrypt(plaintText) {
        let encryptedData = CryptoJS.AES.encrypt(plaintText, this.parsedBase64Key, {
            mode: CryptoJS.mode.ECB,
            padding: CryptoJS.pad.Pkcs7
        });
        return encodeURIComponent(encryptedData.toString());
    }
}
AESEncryptDecryptService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.0.2", ngImport: i0, type: AESEncryptDecryptService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
AESEncryptDecryptService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.0.2", ngImport: i0, type: AESEncryptDecryptService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.0.2", ngImport: i0, type: AESEncryptDecryptService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return []; } });

class ApiModule {
}
ApiModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.0.2", ngImport: i0, type: ApiModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
ApiModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.0.2", ngImport: i0, type: ApiModule, declarations: [ApiComponent], imports: [HttpClientModule], exports: [ApiComponent] });
ApiModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.0.2", ngImport: i0, type: ApiModule, providers: [AESEncryptDecryptService], imports: [HttpClientModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.0.2", ngImport: i0, type: ApiModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [ApiComponent],
                    imports: [HttpClientModule],
                    exports: [ApiComponent],
                    providers: [AESEncryptDecryptService]
                }]
        }] });

class ApiService {
    constructor() { }
}
ApiService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.0.2", ngImport: i0, type: ApiService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
ApiService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.0.2", ngImport: i0, type: ApiService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.0.2", ngImport: i0, type: ApiService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return []; } });

const BASE_URL_LOCAL = 'http://localhost:9090/api/';
const BASE_URL_DEV = 'https://dev.preppednplated.com/api/api/';
const BASE_URL_PROD = 'https://preppednplated.com/api/api/';
//* login related endpoints */
const GENERATE_TOKEN = 'user/generateToken';
const GET_USER_DETAILS = 'user/getUserDetails';
const FATCH_USERDETAILS_BY_ID_ENDPOINT = 'user/getuserdetailsbyid/';
const FATCH_CUSTOMER_DETAILS = 'user/getCustomerList';
const GET_CUSTOMER_DETAILS = 'user/getuserdetailsbyid/<cus_id>';
const SEARCH_CUSTOMER_ENDPOINT = 'user/getCustomerList';
//** Product related endpoints */
//! user prefix on below endpoints must be changed after the service fixup
const FETCH_ALL_CATEGORIES_ENDPOINT = 'products/getCategoryList';
const DELETE_CATEGORY_ENDPOINT = 'user/deleteCategory?catId=<cat_id>';
const CHANGE_CATEGORY_ENDPOINT = 'user/changeCategoryStatus?catId=<cat_id>&status=<status_code>';
const ADD_CATEGORY_ENDPOINT = 'user/addCategory';
const ADD_DISH_ENDPOINT = 'user/addDish';
const FEATCH_ALL_DISHTYPE_ENDPOINT = 'user/getDishList';
const DELETE_DISH_ENDPOINT = 'user/deleteDish?dishId=<dish_id>';
const CHANGE_DISH_STATUS_ENDPOINT = 'user/changeDishStatus?dishId=<dish_id>&status=<status_code>';
const ADD_MEAL_ENDPOINT = 'user/addMeal';
const FATCH_ALLMEAL_ENDPOINT = 'user/getMealList';
const DELETE_MEAL_ENDPOINT = 'user/deleteMeal?mealId=<meal_id>';
const CHANGE_MEAL_STATUS_ENDPOINT = 'user/changeMealStatus?mealId=<meal_id>&status=<status_code>';
const ADD_WEEKLYMENU_ENDPOINT = 'user/addweeklymenu';
const FETCH_ALL_WEEKLY_MENU_ENDOINT = 'user/getWeeklyMenulist';
const FETCH_ALL_ACTIVE_WEEKLY_MENU_ENDOINT = 'user/getActiveWeeklyMenulist';
const DELETE_WEEKLY_MENU_ENDPOINT = 'user/deleteweeklyMenu?menuId=<menu_Id>';
const CHANGE_WEEKLY_MENU_STATUS_ENDPOINT = 'user/changeWeeklyMenuStatus?menuId=<menu_id>&status=<status_code>';
const SEARCH_ITEMS_ENDPOINT = 'products/items';
const ADD_ITEM_ENDPOINT = 'products/items/add';
const DELETE_ITEM_ENDPOINT = 'products/items/delete?itemId=<item_id>';
const GET_ITEM_ENDPOINT = 'products/items/<item_slug>';
const CHANGE_ITEM_STATUS_ENDPOINT = 'products/items/changeStatus?itemId=<item_id>&status=<status_code>';
const UPLOAD_ITEM_FILE = 'fe/uploadSingleFileInFolder';
const FORGET_PASSWORD_ENDPOINT = 'user/sendForgetPasswordMailLink';
const FATCH_EMAIL_BY_TOKEN_ENDPOINT = 'user/findEmailByToken/';
const UPDATE_PASSWORD_BY_ID = 'user/updatepasswordbyid';
const RESET_PASSWORD_ENDPOINT = 'user/resetpasswordbyId';
const GET_ALL_ACTIVE_MENU_DETAILS_ENDPOINT = 'products/activeMenuDetails';
const CREATE_MENU_ITEM_ENDPOINT = 'products/menuitem';
const GET_CHOSEN_ITEMS = 'products/chosenItems?id=<menu_detail_id>';
const GET_REMAINING_ITEMS = 'products/remainingItems?id=<menu_detail_id>';
const SEARCH_ORDERS_ENDPOINT = 'orders';
const FETCH_ALL_ORDER_STATUS = 'orders/status';
const FETCH_ORDER_BY_ID = 'orders/<order_id>';
const CHANGE_ORDER_STATUS = 'orders/changeStatus?orderId=<order_id>&orderStatus=<order_status>';
const GENERATE_EXPORT_EXCEL_ENDPOINT = 'orders/export/<menu_option_id>';
const DOWNLOAD_MEDIA_ENDPOINT = 'fe/downloadMedia/<file_name>';
const GET_ACTIVE_MENU_OPTIONS = 'user/getActiveWeeklyMenulist';
const GET_ACTIVE_CATEGORIES_ENDPOINT = 'products/getActiveCategoryList';
const GET_ACTIVE_DISH_TYPES_ENDPOINT = 'user/getActiveDishTypeList';
const GET_ACTIVE_MEAL_TYPES_ENDPOINT = 'user/getActiveMealList';
const GET_ALL_LOCATION_ENDPOINT = 'picklocation/getallpickuplocation';
const ADD_PICKUP_LOCATION_ENDPOINT = 'picklocation/add';
const DELETE_BY_ID_LOCATION_ENDPOINT = 'picklocation/delete/';
const CHANGE_STATUS_ENDPOINT = 'picklocation/changestatus';
const SEND_CUSTOM_MAIL_ENDPOINT = 'orders/sendmail';
const FETCH_ALL_DELIVERY_ZONES_ENDPOINT_PAGINATION = 'zipcode/fetchallzipcodelist';
const FETCH_ALL_DELIVERY_ZONES_ENDPOINT = 'zipcode/fetchallzipcode';
const DELETE_DELEVERY_ZONES_ENDPOINT = 'zipcode/deletezip/';
const ADD_DELIVERY_ZONES_ENDPOINT = 'zipcode/add';
const update_Bag_Management_ENDPOINT = 'orders/updatecoolerbagreturn/';
const GENERATE_ORDER_ROUTING_EXCEL_ENDPOINT = 'orders/generateOrderRoutingInstructions?date=<delivery_date>&fileType=<type>';
const GENERATE_ORDER_LABEL_EXCEL_ENDPOINT = 'orders/generateOrderForm?date=<delivery_date>&fileType=<type>';
const GENERATE_ORDER_INVOICE_ENDPOINT = 'pdfcontroller/downloadOrderPDF?startDate=<delivery_date>';
const GENERATE_ORDER_INVOICEPDF_ENDPOINT = 'pdfcontroller/downloadPDF?orderId=<order_id>';
const GEN_CUSTOMER_LIST = 'orders/generateCustomerList';
/************************* Menu Related **********************************************/
const FETCH_ALL_MENU_STATUS = 'menu/status';
const FETCH_MENU_DETAILS_BY_ID = 'menu/details/<id>';
const FETCH_MENU_DEADLINE_DATE = 'menu/deadlineDate?menuOptionSlug=<menu_option_slug>&deliveryDate=<delivery_date>';
const FETCH_ALL_MENU_DETAILS = 'menu';
const FETCH_MENU_DETAILS_BY_MENU_OPTION_AND_DELIVERY_DATE = 'menu/details?menuOption=<menu_option_slug>&deliveryDate=<delivery_date>';
const FETCH_MENU_ITEMS_BY_MENU_OPTION_AND_DELIVERY_DATE = 'menu/items?menuOption=<menu_option_slug>&deliveryDate=<delivery_date>';
const CREATE_MENU = 'menu/create';
const FETCH_CHOSEN_ITEMS = 'menu/chosenItems?detail=<id>';
const FETCH_REMAINING_ITEMS = 'menu/remainingItems?detail=<id>';
const PUBLISH_MENU = 'menu/publish/<menu_option_id>/<details_id>';
const DELETE_MENU = 'menu/details/<id>';
const FETCH_PUBLISHED_MENU_BY_MENU_OPTION = 'menu/details/getPublishedMenu?menuOption=<menu_option_slug>';
/********************* Coupon Related ***********************************************/
const FETCH_COUPONS = 'coupon/fetchCoupons';
const FETCH_COUPON_BY_CODE = 'coupon/<code>';
const ADD_COUPONS = 'coupon/addCoupon';
const CHANGE_COUPON_STATE = 'coupon/toggleActiveState?state=<active_state>&couponId=<coupon_id>';
/*********************** Subscription Related **************************************/
const SAVE_CARD = 'cards/saveCard';
const FETCH_CARDS_BY_CUSTOMER_ID_OR_USER_ID = 'cards?customerId=<customer_id>&userId=<user_id>';
const FETCH_CARDS_BY_USER_ID = 'cards?userId=<userId>';

var enumHttpMethods;
(function (enumHttpMethods) {
    enumHttpMethods[enumHttpMethods["GET"] = 0] = "GET";
    enumHttpMethods[enumHttpMethods["POST"] = 1] = "POST";
})(enumHttpMethods || (enumHttpMethods = {}));
class HttpService {
    constructor(client, router) {
        this.client = client;
        this.router = router;
    }
    get(baseUrl, url) {
        return this.client.get(baseUrl + url);
    }
    post(baseUrl, url, payload) {
        return this.client.post(baseUrl + url, payload);
    }
    delete(baseUrl, url) {
        return this.client.delete(baseUrl + url);
    }
    fileUploadRequest(baseUrl, url, formData) {
        let headers = new HttpHeaders();
        headers.append('Content-Type', 'multipart/form-data');
        headers.append('Accept', 'application/json');
        return this.client.post(baseUrl + url, formData, { headers: headers });
    }
}
HttpService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.0.2", ngImport: i0, type: HttpService, deps: [{ token: i1.HttpClient }, { token: i2.Router }], target: i0.ɵɵFactoryTarget.Injectable });
HttpService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.0.2", ngImport: i0, type: HttpService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.0.2", ngImport: i0, type: HttpService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: i1.HttpClient }, { type: i2.Router }]; } });

/*
 * Public API Surface of api
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ADD_CATEGORY_ENDPOINT, ADD_COUPONS, ADD_DELIVERY_ZONES_ENDPOINT, ADD_DISH_ENDPOINT, ADD_ITEM_ENDPOINT, ADD_MEAL_ENDPOINT, ADD_PICKUP_LOCATION_ENDPOINT, ADD_WEEKLYMENU_ENDPOINT, AESEncryptDecryptService, ApiComponent, ApiModule, ApiService, BASE_URL_DEV, BASE_URL_LOCAL, BASE_URL_PROD, CHANGE_CATEGORY_ENDPOINT, CHANGE_COUPON_STATE, CHANGE_DISH_STATUS_ENDPOINT, CHANGE_ITEM_STATUS_ENDPOINT, CHANGE_MEAL_STATUS_ENDPOINT, CHANGE_ORDER_STATUS, CHANGE_STATUS_ENDPOINT, CHANGE_WEEKLY_MENU_STATUS_ENDPOINT, CREATE_MENU, CREATE_MENU_ITEM_ENDPOINT, DELETE_BY_ID_LOCATION_ENDPOINT, DELETE_CATEGORY_ENDPOINT, DELETE_DELEVERY_ZONES_ENDPOINT, DELETE_DISH_ENDPOINT, DELETE_ITEM_ENDPOINT, DELETE_MEAL_ENDPOINT, DELETE_MENU, DELETE_WEEKLY_MENU_ENDPOINT, DOWNLOAD_MEDIA_ENDPOINT, FATCH_ALLMEAL_ENDPOINT, FATCH_CUSTOMER_DETAILS, FATCH_EMAIL_BY_TOKEN_ENDPOINT, FATCH_USERDETAILS_BY_ID_ENDPOINT, FEATCH_ALL_DISHTYPE_ENDPOINT, FETCH_ALL_ACTIVE_WEEKLY_MENU_ENDOINT, FETCH_ALL_CATEGORIES_ENDPOINT, FETCH_ALL_DELIVERY_ZONES_ENDPOINT, FETCH_ALL_DELIVERY_ZONES_ENDPOINT_PAGINATION, FETCH_ALL_MENU_DETAILS, FETCH_ALL_MENU_STATUS, FETCH_ALL_ORDER_STATUS, FETCH_ALL_WEEKLY_MENU_ENDOINT, FETCH_CARDS_BY_CUSTOMER_ID_OR_USER_ID, FETCH_CARDS_BY_USER_ID, FETCH_CHOSEN_ITEMS, FETCH_COUPONS, FETCH_COUPON_BY_CODE, FETCH_MENU_DEADLINE_DATE, FETCH_MENU_DETAILS_BY_ID, FETCH_MENU_DETAILS_BY_MENU_OPTION_AND_DELIVERY_DATE, FETCH_MENU_ITEMS_BY_MENU_OPTION_AND_DELIVERY_DATE, FETCH_ORDER_BY_ID, FETCH_PUBLISHED_MENU_BY_MENU_OPTION, FETCH_REMAINING_ITEMS, FORGET_PASSWORD_ENDPOINT, GENERATE_EXPORT_EXCEL_ENDPOINT, GENERATE_ORDER_INVOICEPDF_ENDPOINT, GENERATE_ORDER_INVOICE_ENDPOINT, GENERATE_ORDER_LABEL_EXCEL_ENDPOINT, GENERATE_ORDER_ROUTING_EXCEL_ENDPOINT, GENERATE_TOKEN, GEN_CUSTOMER_LIST, GET_ACTIVE_CATEGORIES_ENDPOINT, GET_ACTIVE_DISH_TYPES_ENDPOINT, GET_ACTIVE_MEAL_TYPES_ENDPOINT, GET_ACTIVE_MENU_OPTIONS, GET_ALL_ACTIVE_MENU_DETAILS_ENDPOINT, GET_ALL_LOCATION_ENDPOINT, GET_CHOSEN_ITEMS, GET_CUSTOMER_DETAILS, GET_ITEM_ENDPOINT, GET_REMAINING_ITEMS, GET_USER_DETAILS, HttpService, PUBLISH_MENU, RESET_PASSWORD_ENDPOINT, SAVE_CARD, SEARCH_CUSTOMER_ENDPOINT, SEARCH_ITEMS_ENDPOINT, SEARCH_ORDERS_ENDPOINT, SEND_CUSTOM_MAIL_ENDPOINT, UPDATE_PASSWORD_BY_ID, UPLOAD_ITEM_FILE, enumHttpMethods, update_Bag_Management_ENDPOINT };
//# sourceMappingURL=api.mjs.map
