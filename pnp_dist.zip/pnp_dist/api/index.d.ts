/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="api" />
export * from './public-api';
