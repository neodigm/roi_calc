import * as CryptoJS from 'crypto-js';
import * as i0 from "@angular/core";
export declare class AESEncryptDecryptService {
    secretKey: string;
    encryptedBase64Key: string;
    parsedBase64Key: CryptoJS.lib.WordArray;
    substitutionsBeforeDecryption: Map<string, string>;
    constructor();
    decrypt(encryptedCipherText: any): string;
    encrypt(plaintText: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AESEncryptDecryptService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AESEncryptDecryptService>;
}
