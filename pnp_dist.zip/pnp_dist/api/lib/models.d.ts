export declare namespace Models {
    namespace Schemas {
        interface AddAddressDto {
            id?: number;
            userId?: string;
            ref_id?: number;
            street1?: string;
            street2?: string;
            city?: string;
            state?: string;
            postal_code?: string;
            default_address?: boolean;
        }
        interface AddCategoryDto {
            categoryName?: string;
            status?: string;
            isDeleted?: number;
        }
        interface AddDishDto {
            dishTypeName?: string;
            status?: string;
            isDeleted?: number;
        }
        interface AddMealTypeDto {
            mealTypeName?: string;
            status?: string;
            isDeleted?: number;
        }
        interface ApiResponse {
            status?: number;
            code?: string;
            message?: string;
            data?: {
                [key: string]: any;
            };
            recordCount?: number;
        }
        interface AttachmentVo {
            id?: number;
            fileId?: string;
            fileName?: string;
            refId?: number;
            formCode?: string;
            fileUrl?: string;
            mediaType?: string;
            userId?: number;
        }
        interface CartAnalyticsSearchDto {
            firstName?: string;
        }
        interface CartInputDto {
            userId: number;
            item: CartItemsVo;
            menuDetailsId: number;
            menuOptionId: number;
            deleteExistingCart?: boolean;
        }
        interface CartItemInputDto {
            item: string;
            user: number;
            qty: number;
        }
        interface CartItemsVo {
            id?: number;
            itemName?: string;
            mainItemId?: string;
            itemSlug?: string;
            categoryName?: string;
            mealTypeName?: string;
            dishTypeName?: string;
            itemPrice?: string;
            itemQty?: string;
            itemPic?: string;
            cartVo?: CartVo;
        }
        interface CartVo {
            id?: number;
            userVo?: UserVo;
            refOrderModeType?: RefOrderModeType;
            shippingAddress?: UserAddressVo;
            pickupLocation?: PickupLocationVo;
            menuOption?: WeeklyMenuVo;
            menuDetails?: MenuDetailsVo;
            cartItems?: CartItemsVo[];
            gratuityType?: string;
            gratuityAmount?: string;
            gratuityPercentage?: string;
            coolerBagRequired?: boolean;
            coolerBagAmount?: string;
            deliveryFee?: string;
            deliveryDate?: string;
            instructions?: string;
            cart_deadline?: string;
            squareOrderId?: string;
            routingInstructions?: string;
            taxAmount?: string;
            discount?: string;
            couponId?: number;
            isDeleted?: string;
            empty?: boolean;
        }
        interface CategoryVo {
            id?: number;
            categoryName?: string;
            status?: string;
            isDeleted?: number;
        }
        interface Coupons {
            id?: number;
            couponCode?: string;
            couponDesc?: string;
            couponMsg?: string;
            effectiveStartDate?: string;
            effectiveEndDate?: string;
            discountPercentage?: number;
            discountAmount?: number;
            minOrderAmount?: number;
            discountType?: 'PERCENTAGE' | 'AMOUNT';
            maxDiscountAmount?: number;
            noOfUses?: number;
            activeState?: 'I' | 'A';
            isForNewUsers?: 'N' | 'Y';
            effectiveStartDateStr?: string;
            effectiveEndDateStr?: string;
            page?: number;
            size?: number;
            couponStatus?: string;
            noOfCouponsUsed?: number;
        }
        interface DeliveryZonesDto {
            size?: number;
            page?: number;
            zip_code?: string;
            weekly_option_id?: string;
            orderByColName?: string;
            orderBy?: string;
        }
        interface DishTypeVo {
            id?: number;
            dishTypeName?: string;
            status?: string;
            isDeleted?: number;
        }
        interface FileResponseVo {
            respMsg?: string;
            fileName?: string;
            fileUrl?: string;
            fileId?: string;
        }
        interface GrantedAuthority {
            authority?: string;
        }
        interface ItemDetailsDto {
            id?: number;
            item_id?: number;
            item_name?: string;
            item_code?: string;
            colories?: string;
            fat?: string;
            protein?: string;
            order_instructions?: string;
            reheat_instructions?: string;
            item_slug?: string;
            is_new?: string;
            price?: string;
            weekly_menu_name?: string;
            week_day?: string;
            menu_option_slug?: string;
            file_url?: string;
            category_name?: string;
            meal_type_name?: string;
            dish_type_name?: string;
            menu_option_id?: number;
        }
        interface Items {
            itemId?: number;
            category?: CategoryVo;
            mealType?: MealTypeVo;
            dishType?: DishTypeVo;
            itemName?: string;
            itemCode?: string;
            slug?: string;
            price?: string;
            status?: string;
            orderInstructions?: string;
            reheatInstructions?: string;
            fat?: string;
            carbs?: string;
            protein?: string;
            calories?: string;
            createdTs?: string;
            updatedTs?: string;
            createdBy?: number;
            lastModifiedBy?: number;
            fileId?: string;
            uploadedFiles?: AttachmentVo[];
            fileUrl?: string;
            weeklymenu?: WeeklyMenuVo;
            new?: boolean;
            deleted?: boolean;
        }
        interface ItemsPaginationDto {
            itemId?: number;
            itemName?: string;
            orderByColumn?: string;
            categoryName?: string;
            mealTypeName?: string;
            dishTypeName?: string;
            isActive?: string;
            menuOptionId?: string;
            status?: string;
            size?: number;
            page?: number;
        }
        interface MealTypeVo {
            id?: number;
            mealTypeName?: string;
            status?: string;
            isDeleted?: number;
        }
        interface MenuDetailsInputDto {
            page?: number;
            size?: number;
            order?: string;
            orderBy?: string;
            deliveryMenu?: string;
            menuStatus?: string;
            deliveryDate?: string;
        }
        interface MenuDetailsVo {
            id?: number;
            menuOption?: WeeklyMenuVo;
            menuStatus?: RefMenuStatus;
            deliveryDate?: string;
            deadlineTs?: string;
            createdBy?: number;
            createdTs?: string;
            updatedTs?: string;
            menuItems?: Items[];
        }
        interface MenuItemsDto {
            menuDetails?: MenuDetailsVo;
            items?: Items[];
        }
        interface MenuItemsInputPaginationDto {
            itemName?: string;
            menuOptionSlug?: string;
            categories?: string[];
            mealTypes?: string[];
            dishTypes?: string[];
            page?: number;
            size?: number;
            orderByColumn?: string;
            sortOrder?: number;
        }
        interface OrderItems {
            id?: number;
            order?: Orders;
            itemId?: number;
            itemName?: string;
            itemCode?: string;
            itemSlug?: string;
            price?: string;
            categoryName?: string;
            dishTypeName?: string;
            mealTypeName?: string;
            qty?: number;
            orderInstructions?: string;
            reheatInstructions?: string;
            fat?: string;
            carbs?: string;
            protein?: string;
            calories?: string;
            totalAmount?: number;
            uploadedFile?: AttachmentVo;
            new?: boolean;
        }
        interface OrderPaginationInputDto {
            userId?: string;
            orderId?: string;
            orderStartDate?: string;
            orderEndDate?: string;
            orderDeliveryStartDate?: string;
            orderDeliveryEndDate?: string;
            customerName?: string;
            customerPhone?: string;
            customerEmail?: string;
            orderStatus?: string;
            size?: number;
            page?: number;
            orderByMode?: number;
            orderByColumn?: string;
            coolerBagRequired?: boolean;
        }
        interface OrderShipping {
            id?: number;
            order?: Orders;
            refAddressType?: RefAddressTypeVo;
            street1?: string;
            street2?: string;
            city?: string;
            state?: string;
            postalCode?: string;
            country?: string;
        }
        interface Orders {
            orderId?: string;
            orderDate?: string;
            orderDeliveryDate?: string;
            user?: UserVo;
            orderItems?: OrderItems[];
            refOrderModeType?: RefOrderModeType;
            refOrderStatus?: RefOrderStatus;
            shippingAddress?: OrderShipping;
            pickupLocation?: PickupLocationVo;
            routingInstructions?: string;
            menuOption?: WeeklyMenuVo;
            taxAmount?: number;
            deliveryFee?: number;
            packagingFee?: number;
            coolerBagRequired?: boolean;
            coolerBagAmount?: number;
            gratuityType?: string;
            gratuityPercentage?: number;
            gratuityAmount?: number;
            discount?: number;
            bagTotal?: number;
            grandTotal?: number;
            txnId?: string;
            squareOrderId?: string;
            paymentStatus?: string;
            createdTs?: string;
            updatedTs?: string;
            isCoolerbagReturn?: string;
            createdBy?: number;
            couponOrderMst?: Coupons;
        }
        interface PickupLocationVo {
            id?: number;
            location_name?: string;
            street1?: string;
            street2?: string;
            city?: string;
            state?: string;
            postal_code?: string;
            status?: string;
            isDeleted?: number;
        }
        interface PlaceOrderInputDto {
            refOrderModeType?: RefOrderModeType;
            menuOption?: WeeklyMenuVo;
            shippingAddress?: UserAddressVo;
            pickupLocation?: PickupLocationVo;
            coolerBagRequired?: boolean;
            routingInstructions?: string;
            discount?: string;
            couponId?: number;
            paymentMode?: string;
            txnId?: string;
            gratuityPercent?: string;
            gratuityAmount?: string;
            customerId?: number;
        }
        interface RefAddressTypeVo {
            id?: number;
            name?: string;
        }
        interface RefMenuStatus {
            id?: number;
            name?: string;
            seq?: number;
        }
        interface RefOrderModeType {
            id?: number;
            name?: string;
            seq?: string;
        }
        interface RefOrderStatus {
            id?: number;
            name?: string;
            seq?: string;
        }
        interface RemoveCartItemInputDto {
            user: number;
            item: string;
        }
        interface SendMailDto {
            mailTo?: string;
            firstName?: string;
            subject?: string;
            mailDtl?: string;
            mailCC?: string;
        }
        interface SignUpDto {
            firstName?: string;
            lastName?: string;
            emailAddress?: string;
            phoneNo?: string;
            password?: string;
        }
        interface SignUpVo {
            emailOrPhone?: string;
            password?: string;
            firstName?: string;
            lastName?: string;
            phone?: string;
            createdBy?: string;
            adminUserId?: number;
        }
        interface UpdatePasswordInputVo {
            id?: number;
            activationToken?: string;
            password?: string;
            newpassword?: string;
            email?: string;
        }
        interface UserAddressVo {
            id?: number;
            User_id?: UserVo;
            ref_id?: RefAddressTypeVo;
            street1?: string;
            street2?: string;
            city?: string;
            state?: string;
            postal_code?: string;
            order_instruction?: string;
            default_address?: string;
            user_id?: UserVo;
        }
        interface UserPaginationInputDto {
            id?: number;
            firstName?: string;
            emailAddress?: string;
            phoneNo?: string;
            size?: number;
            page?: number;
            orderByColName?: string;
            orderBy?: string;
            lastName?: string;
        }
        interface UserVo {
            id?: number;
            firstName?: string;
            lastName?: string;
            dateOfBirth?: string;
            emailAddress?: string;
            phoneNo?: string;
            phoneVerificationPin?: string;
            activeStatus?: string;
            userRole?: string;
            referralCode?: string;
            createdTs?: string;
            createdBy?: string;
            lastLoginTs?: string;
            username?: string;
            activationToken?: string;
            creditWallet?: number;
            address?: UserAddressVo[];
            page?: number;
            size?: number;
            orderByColName?: string;
            orderBy?: string;
            enabled?: boolean;
            fullName?: string;
            authorities?: GrantedAuthority[];
            accountNonExpired?: boolean;
            accountNonLocked?: boolean;
            credentialsNonExpired?: boolean;
        }
        interface WeeklyMenuDto {
            weeklyMenu?: string;
            weekDay?: string;
            status?: string;
            deadline_day?: string;
            deadlineTime?: string;
        }
        interface WeeklyMenuVo {
            id?: number;
            slug?: string;
            weekDay?: string;
            deadline_day?: string;
            deadlineTime?: string;
            status?: string;
            isDeleted?: number;
            delivery_date?: string;
            weeklyMenuName?: string;
        }
        interface ZipCodeDeliveryVo {
            id?: number;
            zip_code?: string;
            weekly_option_id?: WeeklyMenuVo;
            delivery_amount?: string;
            tax_rate?: string;
        }
    }
}
