import * as i0 from "@angular/core";
import * as i1 from "./api.component";
import * as i2 from "@angular/common/http";
export declare class ApiModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ApiModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ApiModule, [typeof i1.ApiComponent], [typeof i2.HttpClientModule], [typeof i1.ApiComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ApiModule>;
}
