import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import * as i0 from "@angular/core";
export declare enum enumHttpMethods {
    'GET' = 0,
    'POST' = 1
}
export declare class HttpService {
    private client;
    private router;
    constructor(client: HttpClient, router: Router);
    get(baseUrl: string, url: string): import("rxjs").Observable<Object>;
    post(baseUrl: string, url: string, payload: any): import("rxjs").Observable<Object>;
    delete(baseUrl: string, url: string): import("rxjs").Observable<Object>;
    fileUploadRequest(baseUrl: string, url: string, formData: FormData): import("rxjs").Observable<Object>;
    static ɵfac: i0.ɵɵFactoryDeclaration<HttpService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HttpService>;
}
