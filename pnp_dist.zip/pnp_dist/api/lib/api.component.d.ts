import * as i0 from "@angular/core";
export declare class ApiComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ApiComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ApiComponent, "pnp-api", never, {}, {}, never, never, false, never>;
}
